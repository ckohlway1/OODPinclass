package iteratedManu;

public interface MenuIterator {
	public boolean hasNext();
	public MenuItem next();
}
